package com.example.hiw;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class JokeActivity extends AppCompatActivity {
    RequestQueue requestQueue;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_joke);
        requestQueue = Volley.newRequestQueue(this);
        textView = findViewById(R.id.text1);

        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://icanhazdadjoke.com/";

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(JsonRequest.Method.GET, url, null,
                new Response.Listener<JSONObject>() {


                    @Override
                    public void onResponse(JSONObject response) {
                        try{
                            String s = response.getString("joke");
                            textView.setText(s);
                        }catch (JSONException e){
                            textView.setText("didn't work");
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText("That didn't work!");
            }
        })
        {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String>  params = new HashMap<String, String>();
                params.put("Accept","application/json");
                return params;
            }
        };
        queue.add(jsonObjectRequest);
    }
}