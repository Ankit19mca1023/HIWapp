package com.example.hiw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button sign_up;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sign_up=findViewById(R.id.button2);
    }
    public void Sign_up(View v){
        Intent intent = new Intent(this, Sign_up.class );
        startActivity(intent);
    }
    public void Log_in(View v){
        Intent intent = new Intent(this, Log_in.class );
        startActivity(intent);
    }

}