package com.example.hiw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Sign_up extends AppCompatActivity {

    EditText FullName;
    EditText Phone;
    EditText UserName;
    EditText UserEmail;
    EditText Password;
    EditText A_Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        FullName = findViewById(R.id.FullName);
        Phone = findViewById(R.id.Phone);
        UserEmail = findViewById(R.id.UserEmail);
        UserName = findViewById(R.id.UserName);
        Password = findViewById(R.id.pswrd);
        A_Password = findViewById(R.id.apswrd);
    }
    public void Sign_up(View v){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }
}