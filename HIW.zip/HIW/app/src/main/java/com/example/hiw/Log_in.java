package com.example.hiw;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Log_in extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
    }
    public void Check_up(View v){
        Intent intent = new Intent(this, CheckUp.class );
        startActivity(intent);
    }
    public void RecordCard(View v){
        Intent intent = new Intent(this, ReportRecord.class );

        startActivity(intent);
    }
    public void logOut(View v){
        Intent intent = new Intent(this, MainActivity.class );

        startActivity(intent);
    }
    public void onjoke(View v){
        Intent intent = new Intent(this, JokeActivity.class );

        startActivity(intent);
    }
}